var today = new Date();
var dd = today.getDate();
var mm = today.getMonth() + 1; //January is 0!
var yyyy = today.getFullYear();


var hh = today.getHours();
var min = today.getMinutes();

var currenDt = dd+"-"+mm+"-"+yyyy+"   "+hh+":"+min
var text = document.getElementById("currentDate");
text.innerHTML = currenDt;


function setInputValue(){
	
	var input = document.getElementById("input");
	input.value=currenDt;
	
}