var passClass = document.getElementsByClassName("pw-check");
let up, low, num, sp, len;

function passCheck(data){
	
	const lowercase = new RegExp('(?=.*[a-z])');
	const upperCase = new RegExp('(?=.*[A-Z])');
	const number = new RegExp('(?=.*[0-9])');
	const specialChar = new RegExp('(?=.*[ !@#\$%\*&\*])');
	const eightChar = new RegExp('(?=.{8,})');

    console.log("this is test: ", data);

	if(upperCase.test(data)){
		passClass[1].style.color = "green";
		up =  true;
	}else{
		passClass[1].style.color = "black";
		up = false;
	}
	
	if(lowercase.test(data)){
		passClass[2].style.color = "green";
		low = true;
	}else{
		passClass[2].style.color = "black";
		low = false;
	}
	
	if(specialChar.test(data)){
		passClass[3].style.color = "green";
		sp = true;
	}else{
		passClass[3].style.color = "black";
		sp = false;
	}
	
	if(number.test(data)){
		passClass[4].style.color = "green";
		num = true;
	}else{
		passClass[4].style.color = "black";
		num = false;
	}
	
	if(eightChar.test(data)){
		passClass[5].style.color = "green";
		len = true;
	}else{
		passClass[5].style.color = "black";
		len = false;
	}

}


function validateForm(){
	
	var retrunVal=false;
	
	if (up && low && num && sp && len){
		retrunVal=true;
		
	}else{
		if(!up){
			passClass[1].style.color = "red";
		}
		if(!low){
			passClass[2].style.color = "red";
		}
		if(!sp){
			passClass[3].style.color = "red";
		}
		if(!num){
			passClass[4].style.color = "red";
		}
		if(!len){
			passClass[5].style.color = "red";
		}
		

	}
	return retrunVal;
}

	
let eyeicon = document.getElementById("eyeicon");
let password = document.getElementById("password");

eyeicon.onclick = function(){
	
	if(password.type == "password"){
		password.type = "text";
		eyeicon.className = "fa-solid fa-eye-slash";
	}else{
		password.type = "password";
		eyeicon.className = "fa-solid fa-eye";
	}
}
