 package com.db;
import java.sql.*;

public class DBConnect {
	
	private static Connection conn;
	
	public static  Connection getConn() {
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms", "root", "1234");
			return conn;
			
		} catch (ClassNotFoundException e) {
			System.out.println(e);
			return null;
			
		}catch (SQLException e) {
			System.out.println(e);
			return null;
		}

	}
}

