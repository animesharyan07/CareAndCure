package com.admin.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.PharmaDao;
import com.db.DBConnect;

@WebServlet("/updateBill")
public class UpdateStatServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		try {
			
			int id = Integer.parseInt(req.getParameter("id"));
			
			String stat = req.getParameter("stat");
			String am = req.getParameter("am");
			
			PharmaDao dao = new PharmaDao(DBConnect.getConn());
			HttpSession session = req.getSession();
			
			if(dao.updateStat(id, stat, am)) {
				
				session.setAttribute("succMsgd", "Updated!!");
				resp.sendRedirect("admin/viewPharmacy.jsp");
				
			}else {
				
				session.setAttribute("errorMsgd", "Updated!!");
				resp.sendRedirect("admin/viewPharmacy.jsp");
				
			}
			
			
		} catch (Exception e) {
			System.out.println("serv Error"+ req.getParameter("id"));
			e.printStackTrace();
		}
		
	}
	
	

}
