package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.entity.Doctor;

public class DoctorDao {

	private Connection conn;

	public DoctorDao(Connection conn) {
		super();
		this.conn = conn;
	}
	
	public boolean[] registerDoctor(Doctor d) {
		
		boolean[] f = new boolean[2];
		
		try {
			
			String sql = "insert into doctor_details(fullName, DOB, qualification, specialist, email, mobNo, password) values(?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, d.getFullName());
			ps.setString(2, d.getDOB());
			ps.setString(3, d.getQualification());
			ps.setString(4, d.getSpecialist());
			ps.setString(5, d.getEmail());
			ps.setString(6, d.getMobNo());
			ps.setString(7, d.getPassword());
			
			int i = ps.executeUpdate();
			
			if(i==1) {
				f[0] = true;
				f[1] = true;
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			
			String w = e.getMessage();
			
			String a = "'doctor_details.email_UNIQUE'";
			String a1 = "'doctor_details.mobNo_UNIQUE'";
			boolean b = w.matches("(.*)" +a+ "(.*)");
			boolean b1 = w.matches("(.*)" +a1+ "(.*)");
			
			if (b==true) {
				
				f[0] = false;
				f[1] = true;
				
			}
			else if(b1==true) {
				f[0] = true;
				f[1] = false;
			}
		}
		return f;
	}
	
	public List<Doctor> getAllDocs(){
		
		List<Doctor> list = new ArrayList<Doctor>();
		Doctor d = null;
		
		try {
			String sql = "select * from doctor_details order by id desc";
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				
				d = new Doctor();
				d.setId(rs.getInt(1));
				d.setFullName(rs.getString(2));
				d.setDOB(rs.getString(3));
				d.setQualification(rs.getString(4));
				d.setSpecialist(rs.getString(5));
				d.setEmail(rs.getString(6));
				d.setMobNo(rs.getString(7));
				d.setPassword(rs.getString(8));
				
				list.add(d);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
		
	}
	
	
	
	public Doctor getDocById(int id){

		Doctor d = null;
		
		try {
			String sql = "select * from doctor_details where id=?";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				
				d = new Doctor();
				d.setId(rs.getInt(1));
				d.setFullName(rs.getString(2));
				d.setDOB(rs.getString(3));
				d.setQualification(rs.getString(4));
				d.setSpecialist(rs.getString(5));
				d.setEmail(rs.getString(6));
				d.setMobNo(rs.getString(7));
				d.setPassword(rs.getString(8));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return d;
		
	}
	
	public boolean[] updateDoctor(Doctor d) {
		
		boolean[] f = new boolean[2];
		
		try {
			
			String sql = "update doctor_details set fullName=?, DOB=?, qualification=?, specialist=?, email=?, mobNo=?, password=? where id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, d.getFullName());
			ps.setString(2, d.getDOB());
			ps.setString(3, d.getQualification());
			ps.setString(4, d.getSpecialist());
			ps.setString(5, d.getEmail());
			ps.setString(6, d.getMobNo());
			ps.setString(7, d.getPassword());
			ps.setInt(8, d.getId());
			
			int i = ps.executeUpdate();
			
			if(i==1) {
				f[0] = true;
				f[1] = true;
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			
			String w = e.getMessage();
			
			String a = "'doctor_details.email_UNIQUE'";
			String a1 = "'doctor_details.mobNo_UNIQUE'";
			boolean b = w.matches("(.*)" +a+ "(.*)");
			boolean b1 = w.matches("(.*)" +a1+ "(.*)");
			
			if (b==true) {
				
				f[0] = false;
				f[1] = true;
				
			}
			else if(b1==true) {
				f[0] = true;
				f[1] = false;
			}
			else {
				f[0] = false;
				f[1] = false;
			}
		}
		return f;
	}
	
	
	public boolean deleteDoctor(int id) {
		boolean f = false;
		
		try {
			
			String sql = "delete from doctor_details where id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			
			int i = ps.executeUpdate();
			
			if(i==1) {
				f = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return f;
	}
	
	
	public Doctor login(String email, String psw) {
		Doctor d = null;
		
		try {
			
			String sql = "select * from doctor_details where email=? and password=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, email);
			ps.setString(2, psw);
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
			
				d = new Doctor();
				
				d.setId(rs.getInt(1));
				d.setFullName(rs.getString(2));
				d.setDOB(rs.getString(3));
				d.setQualification(rs.getString(4));
				d.setSpecialist(rs.getString(5));
				d.setEmail(rs.getString(6));
				d.setMobNo(rs.getString(7));
				d.setPassword(rs.getString(8));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return d;
	}
	
	
	public int countDoctor() {
		
		int i = 0;
		try {
			
			String val = "SELECT COUNT(*) as rNum FROM doctor_details";

			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(val);
			
			if (rs.next()) {
				
				i = rs.getInt("rNum");

			}
			
			st.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return  i;
	}
	
	public int countAppointment() {
		
		int i = 0;
		try {
			
			String val = "SELECT COUNT(*) as rNum FROM appointment";

			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(val);
			
			if (rs.next()) {
				
				i = rs.getInt("rNum");

			}
			
			st.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return  i;
	}
	
	public int countUser() {
		
		int i = 0;
		try {
			
			String val = "SELECT COUNT(*) as rNum FROM user_details";

			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(val);
			
			if (rs.next()) {
				
				i = rs.getInt("rNum");

			}
			
			st.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return  i;
	}
	
	public int countSpecialist() {
		
		int i = 0;
		try {
			
			String val = "SELECT COUNT(*) as rNum FROM specialist";

			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(val);
			
			if (rs.next()) {
				
				i = rs.getInt("rNum");

			}
			
			st.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return  i;
	}
	
	public int countAppointmentByDoctorId(int did) {
		
		int i = 0;
		try {
			
			String val = "SELECT COUNT(*) as rNum FROM hms.appointment where doctor_id=?";
			
			PreparedStatement ps = conn.prepareStatement(val);
			ps.setInt(1, did);
			
			Statement st = conn.createStatement();
			ResultSet rs = ps.executeQuery();
			
			if (rs.next()) {
				
				i = rs.getInt("rNum");

			}
			
			st.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return  i;
	}
	
	public boolean checkOldPW(int userid, String OldPw) {
		
		boolean f = false;
		
		try {
			
			String sql = "select * from doctor_details where id=? and password=?";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userid);
			ps.setString(2, OldPw);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				
				f = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return f;
	}
	
	
	public boolean changePW(int userid, String NewPW) {
		
		boolean f = false;
		
		try {
			
			String sql = "update doctor_details set password=? where id=?";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, NewPW);
			ps.setInt(2, userid);
			
			
			int i = ps.executeUpdate();
			
			if(i==1) {
				
				f = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return f;
	}
	
public boolean[] editDoctorProfile(Doctor d) {
		
		boolean[] f = new boolean[2];
		
		try {
			
			String sql = "update doctor_details set fullName=?, DOB=?, qualification=?, specialist=?  where id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, d.getFullName());
			ps.setString(2, d.getDOB());
			ps.setString(3, d.getQualification());
			ps.setString(4, d.getSpecialist());
		
			ps.setInt(5, d.getId());
			
			int i = ps.executeUpdate();
			
			if(i==1) {
				f[0] = true;
				f[1] = true;
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			
			String w = e.getMessage();
			
			String a = "'doctor_details.email_UNIQUE'";
			String a1 = "'doctor_details.mobNo_UNIQUE'";
			boolean b = w.matches("(.*)" +a+ "(.*)");
			boolean b1 = w.matches("(.*)" +a1+ "(.*)");
			
			if (b==true) {
				
				f[0] = false;
				f[1] = true;
				
			}
			else if(b1==true) {
				f[0] = true;
				f[1] = false;
			}
			else {
				f[0] = false;
				f[1] = false;
			}
		}
		return f;
	}
	
	
}
