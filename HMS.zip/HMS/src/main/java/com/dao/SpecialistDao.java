package com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.entity.Specialist;

public class SpecialistDao {
	
	private Connection conn;

	public SpecialistDao(Connection conn) {
		super();
		this.conn = conn;
	}
	
	public boolean[] addSpecialist (String spcl) {
		
		boolean[] flag = new boolean[2];
		
		try {
			
			String query = "insert into specialist (spec_name) values(?)";
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, spcl);
			
			int i = ps.executeUpdate();
			if(i==1) {
				flag[0] = true;
				flag[1] = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			String w = e.getMessage();
			
			String a = "'specialist.spec_name_UNIQUE'";
			boolean b = w.matches("(.*)" +a+ "(.*)");
			
			if (b==true) {
				
				flag[0] = false;
				flag[1] = false;
				
			}
			
			else {
				flag[0] = false;
				flag[1] = true;
			}
		}
		
		
		return flag;
	}
	
	
	public List<Specialist> getAllSpecialist(){
		
		List<Specialist> list = new ArrayList<Specialist>();
		Specialist s = null;
		
		try {
			
			String sql = "select * from specialist";
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				
				s= new Specialist();
				s.setId(rs.getInt(1));
				s.setSpecialistName(rs.getString(2));	
				
				list.add(s);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
	
	
}
