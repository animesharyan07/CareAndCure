package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Appointment;
import com.entity.Pharma;

public class PharmaDao {

	private Connection conn;

	public PharmaDao(Connection conn) {
		super();
		this.conn = conn;
	}
	
	public boolean billMed(Pharma p) {
		
		boolean f = false;
		
		try {
			
			String sql = "insert into pharmacy (fullname, user_id, gender, age, phno, doctor, imageName, meds, diseases, address, status, date, Amount) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, p.getFullname());
			ps.setInt(2, p.getUser_id());
			ps.setString(3, p.getGender());
			ps.setString(4, p.getAge());
			ps.setString(5, p.getPhno());
			ps.setString(6, p.getDoctor());
			ps.setString(7, p.getImageName());
			ps.setString(8, p.getMeds());
			ps.setString(9, p.getDiseases());
			ps.setString(10, p.getAddress());
			ps.setString(11, p.getStatus());
			ps.setString(12, p.getDate());
			ps.setString(13, p.getAmount());
	
			int i = ps.executeUpdate();
			
			if(i==1) {
				f = true;
				
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return f;
	}
	
	public List<Pharma> getAllbillByLoginUser(int uid){
		
		List<Pharma> list = new ArrayList<Pharma>();
		Pharma p = null;
		
try {
			
			String sql = "select * from pharmacy where user_id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, uid);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				
				p = new Pharma();
				
				p.setId(rs.getInt(1));
				p.setFullname(rs.getString(2));
				p.setUser_id(rs.getInt(3));
				p.setGender(rs.getString(4));
				p.setAge(rs.getString(5));
				p.setPhno(rs.getString(6));
				p.setDoctor(rs.getString(7));
				p.setImageName(rs.getString(8));
				p.setMeds(rs.getString(9));
				p.setDiseases(rs.getString(10));
				p.setAddress(rs.getString(11));
				p.setStatus(rs.getString(12));
				p.setDate(rs.getString(13));
				p.setAmount(rs.getString(14));
				
				list.add(p);
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
	
	
public List<Pharma> getAllBill(){
		
		List<Pharma> list = new ArrayList<Pharma>();
		Pharma p = null;
		
try {
			
			String sql = "select * from pharmacy order by id desc";
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				
				p = new Pharma();
				
				p.setId(rs.getInt(1));
				p.setFullname(rs.getString(2));
				p.setUser_id(rs.getInt(3));
				p.setGender(rs.getString(4));
				p.setAge(rs.getString(5));
				p.setPhno(rs.getString(6));
				p.setDoctor(rs.getString(7));
				p.setImageName(rs.getString(8));
				p.setMeds(rs.getString(9));
				p.setDiseases(rs.getString(10));
				p.setAddress(rs.getString(11));
				p.setStatus(rs.getString(12));
				p.setDate(rs.getString(13));
				p.setAmount(rs.getString(14));
				
				list.add(p);
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
	
	
public Pharma getBillbyId(int id){
	
	Pharma p = null;
	
try {
		
		String sql = "select * from pharmacy where id=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, id);
		
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			
			p = new Pharma();
			
			p.setId(rs.getInt(1));
			p.setFullname(rs.getString(2));
			p.setUser_id(rs.getInt(3));
			p.setGender(rs.getString(4));
			p.setAge(rs.getString(5));
			p.setPhno(rs.getString(6));
			p.setDoctor(rs.getString(7));
			p.setImageName(rs.getString(8));
			p.setMeds(rs.getString(9));
			p.setDiseases(rs.getString(10));
			p.setAddress(rs.getString(11));
			p.setStatus(rs.getString(12));
			p.setDate(rs.getString(13));
			p.setAmount(rs.getString(14));
			
			/*
			 * System.out.println(rs.getInt(1)); System.out.println(rs.getString(2));
			 * System.out.println(rs.getInt(3)); System.out.println(rs.getString(4));
			 * System.out.println(rs.getString(5)); System.out.println(rs.getString(6));
			 * System.out.println(rs.getString(7)); System.out.println(rs.getString(8));
			 * System.out.println(rs.getString(9)); System.out.println(rs.getString(10));
			 * System.out.println(rs.getString(11)); System.out.println(rs.getString(12));
			 * System.out.println(rs.getString(13)); System.out.println(rs.getString(14));
			 */
		}
			
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	
	return p;
}


	public boolean updateStat(int id, String stat, String am) {
		boolean f = false;
		
		try {
			
			String sql = "Update pharmacy set status=?, Amount=? where id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, stat);
			ps.setString(2, am);
			ps.setInt(3, id);
			
			int i = ps.executeUpdate();
			
			if(i==0) {
				f = true;
			}
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		return f;
	}

	
}
