package com.dao;

import java.net.ConnectException;
import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpSession;

import com.entity.User;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.xdevapi.PreparableStatement;

public class UserDao {
	
	private Connection conn;

	public UserDao(Connection conn) {
		super();
		this.conn = conn;
	}
	
	
	public boolean[] userRegister(User u) {
		
		boolean[] flag = new boolean[2];
		
		try {
			
			
			String val = "SELECT COUNT(*) as rNum FROM user_details";
			int idval = 0;
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(val);
			
			if (rs.next()) {
				
				idval = rs.getInt("rNum");
				idval = idval+1;
			}
			
			st.close();
			
			String sql = "insert into user_details(id, full_name, email, password) values(?,?, ?, ?)";
			
			PreparedStatement ps= conn.prepareStatement(sql);
			ps.setInt(1, idval );
			ps.setString(2, u.getFullName());
			ps.setString(3, u.getEmail());
			ps.setString(4, u.getPassword());
			
			
			int i = ps.executeUpdate();
			
			if(i==1) {
				flag[0] = true;
				flag[1] = true;
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			
			String w = e.getMessage();
			
			String a = "'user_details.email_UNIQUE'";
			boolean b = w.matches("(.*)" +a+ "(.*)");
			
			if (b==true) {
				
				flag[0] = false;
				flag[1] = false;
				
			}
			
			else {
				flag[0] = false;
				flag[1] = true;
			}
			
		}
		
		return flag;
	
	}
	
	
	public User login(String eml, String psw) {
		
		User u = null;
		
		try {
			
			String sql = "select * from user_details where email=? and password=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, eml);
			ps.setString(2, psw);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				
				u=new User();
				u.setId(rs.getInt(1));
				u.setFullName(rs.getString(2));
				u.setEmail(rs.getString(3));
				u.setPassword(rs.getString(4));
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return u;
		
	}
	
	
	public boolean checkOldPW(int userid, String OldPw) {
		
		boolean f = false;
		
		try {
			
			String sql = "select * from user_details where id=? and password=?";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userid);
			ps.setString(2, OldPw);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				
				f = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return f;
	}
	
	
	public boolean changePW(int userid, String NewPW) {
		
		boolean f = false;
		
		try {
			
			String sql = "update user_details set password=? where id=?";
			
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, NewPW);
			ps.setInt(2, userid);
			
			
			int i = ps.executeUpdate();
			
			if(i==1) {
				
				f = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return f;
	}
	
	
}


