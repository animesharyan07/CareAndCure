package com.entity;

public class Pharma {
	
	private int id;
	private String fullname;
	private int user_id;
	private String gender;
	private String age;
	private String phno;
	private String doctor;
	private String imageName;
	private String meds;
	private String diseases;
	private String address;
	private String status;
	private String date;
	private String Amount;
	
	
	public Pharma() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Pharma(String fullname, int user_id, String gender, String age, String phno, String doctor, String imageName,
			String meds, String diseases, String address, String status, String date, String Amount) {
		super();
		this.fullname = fullname;
		this.user_id = user_id;
		this.gender = gender;
		this.age = age;
		this.phno = phno;
		this.doctor = doctor;
		this.imageName = imageName;
		this.meds = meds;
		this.diseases = diseases;
		this.address = address;
		this.status = status;
		this.date = date;
		this.Amount = Amount;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getFullname() {
		return fullname;
	}


	public void setFullname(String fullname) {
		this.fullname = fullname;
	}


	public int getUser_id() {
		return user_id;
	}


	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getAge() {
		return age;
	}


	public void setAge(String age) {
		this.age = age;
	}


	public String getPhno() {
		return phno;
	}


	public void setPhno(String phno) {
		this.phno = phno;
	}


	public String getDoctor() {
		return doctor;
	}


	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}


	public String getImageName() {
		return imageName;
	}


	public void setImageName(String imageName) {
		this.imageName = imageName;
	}


	public String getMeds() {
		return meds;
	}


	public void setMeds(String meds) {
		this.meds = meds;
	}


	public String getDiseases() {
		return diseases;
	}


	public void setDiseases(String diseases) {
		this.diseases = diseases;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}
	
	public String getAmount() {
		return Amount;
	}


	public void setAmount(String Amount) {
		this.Amount = Amount;
	}
	
	

}
