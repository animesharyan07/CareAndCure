package com.user.servlet;

import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.dao.PharmaDao;
import com.db.DBConnect;
import com.entity.Pharma;


@WebServlet("/submitPharma")
@MultipartConfig
public class UserPharmaServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String fullname = req.getParameter("fullname");
		int uid = Integer.parseInt(req.getParameter("userid"));
		String gender = req.getParameter("gender");
		String age = req.getParameter("age");
		String phno = req.getParameter("phno");
		String doctor = req.getParameter("DoctName");
		String meds = req.getParameter("meds");
		String disease = req.getParameter("disease");
		String address = req.getParameter("address");
		String date = req.getParameter("dt");
		
		Part p = req.getPart("files");
		String fileName = p.getSubmittedFileName();
		
		System.out.println("Image name is: "+fileName);
		
		Pharma ph = new Pharma(fullname, uid, gender, age, phno, doctor, fileName, meds, disease, address, "Pending", date, "Pending");
		PharmaDao dao = new PharmaDao(DBConnect.getConn());
		HttpSession session = req.getSession();
		
		if(dao.billMed(ph)) {
			
			session.setAttribute("succMsg", "Submitted Succesfully!");
			resp.sendRedirect("pharmacy.jsp");
			System.out.println("Upload Succes");
			
			String path = getServletContext().getRealPath("")+"ImgUserUpload\\pharmacy";
			System.out.println(path);
			
			File file = new File(path);
			p.write(path+File.separator+fileName);
			
			
		}
		else {
			
			session.setAttribute("errorMsg", "Request can't be accepted right now!");
			resp.sendRedirect("pharmacy.jsp");
			System.out.println("Upload error");
		}
		
	
	}

}
