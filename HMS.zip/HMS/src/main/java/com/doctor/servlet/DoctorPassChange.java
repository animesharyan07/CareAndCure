package com.doctor.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.DoctorDao;
import com.dao.UserDao;
import com.db.DBConnect;

@WebServlet("/doctChangePW")
public class DoctorPassChange extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int did = Integer.parseInt(req.getParameter("did"));
		String oldpass = req.getParameter("oldPW");
		String newpass = req.getParameter("newPW");
		String newpassConf = req.getParameter("newPWconf");
		
		DoctorDao dao =new DoctorDao(DBConnect.getConn());
		HttpSession session = req.getSession();
		
		boolean f1 = dao.checkOldPW(did, oldpass);
		boolean f2 = newpass.matches(newpassConf);
		
		if (f1 & f2) {
			
			boolean f = dao.changePW(did, newpass);
			
			if(f) {
				
				session.setAttribute("succMsg", "Password Updated Succesfully");
				resp.sendRedirect("doctor/editProfile.jsp");
				
			}else {
				
				session.setAttribute("errorMsg", "Something went wron on server...Try later");
				resp.sendRedirect("doctor/editProfile.jsp");
			}
			
		}

		else if(f1==false && f2==true) {
			session.setAttribute("errorMsg", "Old-Pasword doesn't matches");
			resp.sendRedirect("doctor/editProfile.jsp");	
		}
		
		else if(f1==true && f2==false) {
			session.setAttribute("errorMsg", "Confirm-Password doesn't matches!!");
			resp.sendRedirect("doctor/editProfile.jsp");	
		}
		
		else  {
			session.setAttribute("errorMsg", "Both Old-Password and Confirm-Password was typed incorrectly!!");
			resp.sendRedirect("doctor/editProfile.jsp");	
		}
		
	}


}
