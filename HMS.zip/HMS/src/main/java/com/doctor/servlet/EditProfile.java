package com.doctor.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.DoctorDao;
import com.db.DBConnect;
import com.entity.Doctor;

@WebServlet ("/doctorUpdateProfile")
public class EditProfile extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			
			String fullName = req.getParameter("fullname");
			String DOB = req.getParameter("dob");
			String qualification = req.getParameter("qualification");
			String spec = req.getParameter("spec");
			
			
			int id = Integer.parseInt(req.getParameter("did"));
			
			Doctor d = new Doctor(id,fullName, DOB, qualification, spec,"","","");
			
			DoctorDao dao = new DoctorDao(DBConnect.getConn());
			HttpSession session = req.getSession();
			
			boolean[] f = dao.editDoctorProfile(d);
			
			if(f[0]== true && f[1]== true) {
				
				Doctor EditProfile = dao.getDocById(id);
				session.setAttribute("doctObj", EditProfile);
				session.setAttribute("succMsgd", "Doctor Updated Succesfully...");
				resp.sendRedirect("doctor/editProfile.jsp");	
			}
			else if(f[0]==false && f[1]==true) {
				
				session.setAttribute("errorMsgd", "This email already exists");
				resp.sendRedirect("doctor/editProfile.jsp");
			}
			
			else if(f[0]==true && f[1]==false) {
				
				session.setAttribute("errorMsgd", "This mobile number already exists");
				resp.sendRedirect("doctor/editProfile.jsp");
			}
			
			else {
				session.setAttribute("errorMsgd", "Operation can't be executed!");
				resp.sendRedirect("doctor/editProfile.jsp");
			}
			
				} catch (Exception e) {
					e.printStackTrace();
		}
	}

}
